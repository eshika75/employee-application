package employeeApplication;

import java.sql.SQLException;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        EmployeeDaoImpl employeeDao = new EmployeeDaoImpl() {};
        try {
            // Insert a new employee
           //Employee empobj = new Employee(1, "seema", 29, "Manager", 25000);
            //employeeDao.addEmployee(empobj);

            // Update an existing employee
           Employee empobj2 = new Employee(3,"pranav",21,"engineer", 100000);
            employeeDao.updateEmployee(empobj2);
        	
        	

             //Delete an employee
           //employeeDao.deleteEmployee(16);

            // Read an employee by ID
          // Employee emp = employeeDao.readEmployee(15);
           //if (emp != null) {
             //  System.out.println(emp.toString());
           // }

            // Get all employees
//          List<Employee> employees = employeeDao.getAllEmployee();
//            for (Employee empObj : employees) {
//                System.out.println(empObj.toString());
//            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
